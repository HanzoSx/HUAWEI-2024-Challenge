#include "classBoat.hpp"

Boat::Boat() : num(0), pos(-1), status(done) {}

int Boat::boat_capacity = 0;
