#include "classCommand.hpp"

vector<string> Command::RobotCmd, Command::BoatCmd;